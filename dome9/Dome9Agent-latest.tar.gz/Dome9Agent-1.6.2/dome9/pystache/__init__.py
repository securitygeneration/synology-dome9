from dome9.pystache.template import Template
from dome9.pystache.view import View
from dome9.pystache.loader import Loader


def render(template, context=None, **kwargs):
    context = context and context.copy() or {}
    context.update(kwargs)
    return Template(template, context).render()
