import logging
import re
import os
import socket
import struct
import subprocess
import configuration
from ConfigParser import ConfigParser, NoOptionError
from platform import dist


def get_os_version():
    """
    Get OS Version
    First try /etc/issue
    If fails try lsb_config
    """
    # issue may have @ or \ escape chars - remove them
    osver = re.sub(r'[\\@\\].|[/<>*%&:?]', '', ' '.join(dist()))
    if len(osver) > 1:  # is empty dist()
        return osver
    return 'linux-unknown'


def iptables_capabilities(checks):
    """
    Run compatibility checks for installed/required iptables modules
    Return list of iptables capabilities
    """

    rv = {}

    retcode = os.system(r"iptables -F TESTS 1>/dev/null 2>/dev/null")  # May fail
    retcode = os.system(r"iptables -X TESTS 1>/dev/null 2>/dev/null")  # May fail
    retcode = os.system(r"iptables -N TESTS 1>/dev/null 2>/dev/null")
    if retcode:
        logging.error('capabilites: Failed to create TESTS chain.')
        return rv
    for check in checks:
        retcode = os.system(r"iptables -A TESTS %s 1>/dev/null 2>/dev/null" % check[1])
        if retcode:  # error
            rv[check[0]] = 0
        else:  # ok
            rv[check[0]] = 1
    #clear test chain
    retcode = os.system(r"iptables -F TESTS 1>/dev/null 2>/dev/null")
    retcode |= os.system(r"iptables -X TESTS 1>/dev/null 2>/dev/null")
    if retcode:
        logging.debug("capabilites: Can't remove TESTS chain")
    return rv


def getdome9ips():
    """
    Resolve hostname for dome9 servers
    """
    ips = {}
    config = configuration.Config.get_config()
    try:
        ips['agent_host'] = socket.gethostbyname(config.connection.host)
        ips['agent_host_port'] = config.connection.port
        ips['notification_host'] = socket.gethostbyname(config.poller.host)
        ips['notification_host_port'] = config.poller.port
    except socket.error:
        logging.warning(
            'Could not resolve dome9 server names. check agent.conf')
    return ips


def get_server_name():
    """Get server name"""
    rv = os.getenv('HOSTNAME')
    if not rv:
        try:
            rv = open('/etc/hostname').readline().rstrip()
        except IOError:
            pass
    return rv


def get_agent_state():
    """ Get agent state - pairing, polling, deleted """
    run_config = ConfigParser()

    run_config.read('/tmp/run.conf')
    if not run_config.has_section('agent'):
        return 'pairing'

    try:
        return run_config.get('agent', 'state')
    except NoOptionError:
        return 'pairing'


def ipv4_cidr_to_netmask(bits):
    """ Convert CIDR bits to netmask """
    netmask = ''
    for i in range(4):
        if i:
            netmask += '.'
        if bits >= 8:
            netmask += '%d' % (2 ** 8 - 1)
            bits -= 8
        else:
            netmask += '%d' % (256 - 2 ** (8 - bits))
            bits = 0
    return netmask


def get_gateways():
    """Return default gw and  dict of device:gateway"""

    default_gw = None
    routes_map = {}

    f = open('/proc/net/route')

    routes = f.readlines()[1:]
    routes.sort()

    to_address = lambda x: socket.inet_ntoa(struct.pack("<L", int(x, 16)))

    for route in routes:
        (iface, dest, gateway, flags, refcnt, use, metric,
         mask, mtu, window, irtt) = route.strip().split()

        dest = to_address(dest)
        gateway = to_address(gateway)
        mask = to_address(mask)

        if dest == '0.0.0.0':
            default_gw = gateway

        # we take the 1st found route
        if iface not in routes_map:
            routes_map[iface] = gateway

    f.close()

    return default_gw, routes_map


def get_networking_info():
    """Get network devices list, suitable for 'Report method' """

    cmd = subprocess.Popen(['/sbin/ip', 'addr', 'show'], stdout=subprocess.PIPE)

    output, errors = cmd.communicate()

    if cmd.returncode != 0:
        logging.error("Can't get networking info")

    lines = output.split('\n')

    device_re = re.compile(r'^\d+:\s+([^:]+):')
    addr_re = re.compile(r'^\s+inet\s([\d.]+)/*(\d*)')

    defalt_gw, gateways = get_gateways()

    device = None
    devices = {}  # Can't use defaultdict as we need Python 2.4 compat

    for line in lines:
        dev_matches = device_re.match(line)

        if dev_matches:
            device = dev_matches.group(1)

            if device not in devices and device != 'lo':
                # create initial device entry
                devices[device] = {
                    'Desc': device,
                    'Gateway': gateways.get(device),
                    'IPs': []
                }
        else:
            if device == 'lo':
                continue

            addr_matches = addr_re.match(line)
            if addr_matches:
                addr, cidr = addr_matches.groups()
                mask = ipv4_cidr_to_netmask(int(cidr or 0))  # cidr could be empty
                devices[device]['IPs'].append(
                    {'IPAddress': addr, 'Mask': mask})

    return [x for x in devices.values() if x['IPs']]
