"""iptables operation"""
import logging
import os
import subprocess
import configuration
from util import iptables_capabilities, getdome9ips
import dome9.pystache as pystache

class IPTablesApplyException(Exception):
    pass

class IPTables(object):
    """Handles iptables ipv4 operations"""

    CHAINS = {
        'input': 'DOME9',
        'output': 'DOME9OUTPUT',
        'blacklist': 'DOME9BLACKLIST',
    }

    BOILERPLATE_FILE = 'iptables.boilerplate'
    IPTABLES_CHECKS = (
        ("has_iptables",  r" -j ACCEPT"),
        ("has_conntrack", r"-m conntrack --ctstate NEW"),
        ("has_connmark",  r"-j CONNMARK --set-mark 1"),
        ("has_state",     r"-m state --state NEW -j ACCEPT"),
        ("has_log_limit", r"-m limit -j LOG")
    )

    OUTBOUND_ACCEPT = ':OUTPUT ACCEPT'
    LOG_DROPPED_INPUT = '-A INPUT -j LOGDROPPEDINBOUND'
    LOG_DROPPED_OUTPUT = '-A OUTPUT -j LOGDROPPEDOUTBOUND'

    def __init__(self):

        self.previous_ruleset = []
        self.ruleset = []
        self.config = configuration.Config.get_config()
        self.run_dir = self.config.agent.run_dir
        self.template_context = {}
        self.template_context.update(
            iptables_capabilities(self.IPTABLES_CHECKS))
        self.template_context.update(getdome9ips())
        self.template_context.update(self.config.firewall)
        logging.debug("template context: %s", self.template_context)

        # Set Boilerplate IPTables rules:
        # Render boilerplate template to iptables rules list
        template_file = os.path.join(
            os.path.abspath(os.path.dirname(__file__)), 'iptables')
        template = pystache.loader.Loader().load_template(
            template_file, extension='boilerplate')
        self.boilerplate = self._sanitize(
            pystache.render(template, self.template_context).split('\n'))

    def backup(self, backup_filename="iptables_backup"):
        """backup rules to a file under run_dir by default"""

        filename = os.path.join(self.run_dir, backup_filename)

        # don't backup if already exists, might be there from a previous crash,
        # see issue #25
        if os.path.exists(filename):
            logging.info('Not backing iptables: backup "%s" exists', filename)
            return

        logging.info("backing up iptables to " + filename)

        try:
            backup_file = open(filename, 'w')
            cmd = subprocess.Popen("iptables-save", stdout=backup_file,
                                   stderr=subprocess.PIPE)
            output, errors = cmd.communicate()
            if cmd.returncode != 0:
                logging.error("error running iptables-save: %s", errors)
            backup_file.close()
            # make sure the correct permissions are set for the file
            os.chmod(filename, 0640)
        except IOError, e:
            logging.error("Can't create iptables backup file: %s", str(e))

    def restore(self, backup_filename="iptables_backup", remove=False):
        """restore rules from backup file under run_dir by default.

        If remove is True (no longer default), deletes the backup file (see
        issue #25)

        """
        filename = os.path.join(self.run_dir, backup_filename)
        logging.info("restoring iptables from " + filename)

        try:
            if (not os.path.exists(filename) or os.path.getsize(filename) < 20):
                raise IOError('%s does not contain iptables-save' % filename)
            backup_ruleset = open(filename).readlines()
            if backup_ruleset:
                return self.commit(backup_ruleset)
        except IOError, e:
            logging.error("Can't read iptables backup file: %s", str(e))
            raise

        try:
            if remove:
                logging.info("Removing backup file")
                os.unlink(filename)
        except IOError, e:
            logging.error("Can't delete iptables backup file: %s", str(e))

    def reset(self):
        """
        Reset rules and apply default policies, should be called upon agent
        startup

        """
        self.commit(self.boilerplate[:])

    def apply(self, policy, is_emergency=False, log_dropped=False):
        """Applies the policy. steps taken:

        - add additional policy rules to boilerplate
        - commit changes

        """

        ruleset = self.boilerplate[:]

        log_outbound = self.config.firewall.enforce_outbound in ('1', 'true')

        # in case of emergency, we allow outbount, no matter the policy
        if is_emergency:
            ruleset.append(self.OUTBOUND_ACCEPT)
            logging.debug("Emergency, allowing outbound")
            log_outbound = False

        # add the policy rules to our chain
        for policy_rule in policy:
            for rule in policy_rule.as_iptable():
                chain = self.CHAINS[policy_rule.rule_type]
                ruleset.append('-A %s %s\n' % (chain, rule))

        if log_dropped:
            ruleset.append(self.LOG_DROPPED_INPUT)
            if log_outbound:
                ruleset.append(self.LOG_DROPPED_OUTPUT)

        committed = self.commit(ruleset)

        if not committed:
            raise IPTablesApplyException("Failed committing iptables policy")

    def _sanitize(self, ruleset, append_commit=False):
        """
        Sanitize the ruleset - remove comments and verify COMMIT is last
        command Needed because we both generate and use iptables-save files
        """
        ruleset = filter(lambda x: x and x[0] not in "#\n ", ruleset)
        if ruleset[-1] != "COMMIT\n" and append_commit:
            ruleset.append("COMMIT\n")
        self.previous_ruleset = self.ruleset
        self.ruleset = ruleset
        return ruleset

    def ruleset_diff(self):
        """get differences between this and previous rulesets"""
        added = [x for x in self.ruleset if x not in self.previous_ruleset]
        removed = [x for x in self.previous_ruleset if x not in self.ruleset]
        return (added, removed)

    def commit(self, ruleset):
        """
        Commit ruleset using iptables-restore
        """

        ruleset = self._sanitize(ruleset, append_commit=True)
        cmd = subprocess.Popen("iptables-restore", stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        policy = '\n'.join(ruleset)
        (output, errors) = cmd.communicate(policy)
        if cmd.returncode != 0:
            logging.error("commit: error running iptables-restore: %s %s \n%s",
                          errors, output, policy)
            return False
        return True

    def emergency_open_ssh(self):
        """
        In case we can't restore the original iptables setting
        and emergency policy fails we open port 22 to all
        """
        return(os.system(
            r"iptables -I INPUT 1 -p tcp --dport 22 -j ACCEPT 2>/dev/null"))
