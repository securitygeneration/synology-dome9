import os
import sys
from datetime import datetime, timedelta

import logging
import random
import socket
import threading
import time

import configuration
from dome9 import VERSION, RELEASE
from iptables import IPTables, IPTablesApplyException
from longpoll import LongPoll
from util import get_os_version, get_networking_info
from verifiedhttpsconnection import VerifiedHTTPSConnection
from xmlreader import xml_to_attr

try:
    import json
except ImportError:
    import simplejson as json


class ShouldExitException(Exception):
    pass


class Dome9Agent(object):
    """Dome9 Agent, polling and handling the various states and policies"""

    PAIR_URL = '/agentservice.svc/agent/PairNewServer'
    AGENT_DATA_URL = '/agentservice.svc/agent/%s/data4?sessionid=%s'
    REPORT_URL = '/agentservice.svc/agent/%(id)s/report?sessionid=%(session_id)s'
    POLL_LOG_INTERVAL = timedelta(minutes=60)

    def __init__(self, options):
        """set delay to intial delay of agent run"""

        self.config = configuration.Config.get_config()

        # Set root logger level to DEBUG
        if self.config.agent.debug == '1':
            log = logging.getLogger()
            log.setLevel(logging.DEBUG)

        self.iptables = IPTables()
        self.control_firewall = False

        self.delay = options.delay
        self.pidfile = options.pidfile
        self.event = threading.Event()
        self.http_connection = self._get_connection()
        self.longpoller = False
        self.reset_executed = False
        self.first_poll = True   # Used to report agent data on first poll
        self.first_policy_applied = False  # Success in applying first policy
                                           # we got from the server ?
        self.last_seen = None    # Used for applying emergency policy if needed

        # this are used for periodic logging of polls
        self.poll_last_logged = None  # Last time we logged poll stats
        self.poll_attempts = 0        # How many polls since the last log
        self.poll_success = 0         # How many successfull polls since last
                                      # log

        if not self._has_enouth_caps():
            logging.info(
                'No conntrack or connmark capabilities found')
            #self.do_exit() #for now do not exit until further investigation

        # Create session_id on agent startup, will be used for GetData and
        # Report calls. See #7
        self.session_id = random.getrandbits(32)

    def _has_enouth_caps(self):
        "Do we have conntrack or connmark caps ?"

        ctx = self.iptables.template_context
        return ctx['has_connmark'] or ctx['has_conntrack']

    def _get_connection(self):
        """Get VerifiedHTTPSConnection with the paired certificate"""

        connection = self.config.connection
        config_dir = configuration.CONFIG_DIR

        conn = VerifiedHTTPSConnection(
            connection.host, int(connection.port),
            key_file=self.config.certificate_filename,
            cert_file=self.config.certificate_filename,
            ca_certs=os.path.join(config_dir, connection.ca_certs),
            strict=int(connection.cert_enforce)
        )
        return conn

    def get_policy(self):
        """Get the policy from dome9 server"""

        agent = self.config.agent

        url = self.AGENT_DATA_URL % (agent.id, self.session_id)
        # debug for #30: Periodic logging, prevent log flooding
        logging.debug("Getting agent data from %s", url)
        self.http_connection = self._get_connection()
        self.http_connection.request("GET", url)
        response = self.http_connection.getresponse().read()
        logging.debug("Poll Data: %s", response)

        agent_data = xml_to_attr(response).ServerResponse4
        # Error ? raise assertion
        assert not agent_data.Error, agent_data.Error.ErrorNum

        self.config.update_policy(agent_data)

    def report_status(self, is_starting=True):
        """Report agent version, usually runs on first init"""

        agent = self.config.agent

        query_params = {
            'id': agent.id,
            'session_id': self.session_id
        }

        params = {
            'Platform': 'Linux',
            'AgentVersion': '%s.%s' % (VERSION, RELEASE),
            'OSVersion': get_os_version(),
            'Hostname': socket.gethostname(),
            'IsStarting': is_starting,
            'NICs': get_networking_info(),
        }

        url = self.REPORT_URL % query_params
        headers = {'Content-Type': 'application/json', 'charset': 'utf-8'}

        logging.info("Reporting agent status to %s", url)

        self.http_connection = self._get_connection()

        self.http_connection.request("POST", url, json.dumps(params), headers)
        response = self.http_connection.getresponse().read()

        result = xml_to_attr(response)
        success = result.get('boolean', False)
        if success != 'true':
            logging.error('Report failure: %s', response)

    def do_emergency(self):
        """Execute emergency policy, if exists"""

        emergency_policy = self.config.get('emergency_policy', None)
        if not emergency_policy:
            return False
        logging.info("Applying emergency policy")
        self.iptables.reset()
        self.reset_executed = True
        try:
            self.iptables.apply(emergency_policy, is_emergency=True)
            self.control_firewall = True
        except IPTablesApplyException:
            logging.error('Applying emergency policy failed', exc_info=True)
            self.control_firewall = False

        return self.control_firewall

    def do_polling(self):
        """Handle the polling phase. Calls report_status if first run"""

        logging.debug("Doing poll...")
        self.event.clear()
        # if we're paired report agent data on agent init
        if self.first_poll:
            self.report_status()
            self.first_poll = False
            #start async long polling
            if self.config.poller.enabled == '1' or \
                    self.config.poller.enabled == 'True':
                logging.info("Starting Thread...")
                self.longpoller = LongPoll(self.event)
                self.longpoller.setDaemon(True)
                self.longpoller.start()
            else:
                logging.info('LongPoller disabled in config file')

        try:
            # Fixed #30: Periodic loggin, to prevent log flooding
            if not self.poll_last_logged:
                self.poll_last_logged = datetime.now()
            elif datetime.now() - self.poll_last_logged > self.POLL_LOG_INTERVAL:
                logging.info('%d/%d poll attempts in the last %s minutes',
                             self.poll_success, self.poll_attempts,
                             self.POLL_LOG_INTERVAL.seconds / 60)
                self.poll_last_logged = datetime.now()
                self.poll_attempts = 0  # How many polls since the last log
                self.poll_success = 0   # How many successfull polls since last
                                        # log

            self.poll_attempts += 1

            self.get_policy()
            self.config.save()
            self.control_firewall = True

            self.poll_success += 1

            self.last_seen = datetime.now()

            if not self.reset_executed:
                self.iptables.reset()
                self.reset_executed = True

            log_dropped = (self.config.logging_policy.log_dropped in
                           ('1', 'true'))

            try:
                self.iptables.apply(
                    self.config.current_policy + self.config.blacklist +
                    self.config.outbound_policy,
                    log_dropped=log_dropped)
            except:
                logging.error("Error applying policy", exc_info=True)
                if not self.first_policy_applied:
                    raise Exception('FailedFirstPolicy')

            if not self.first_policy_applied:
                self.first_policy_applied = True

            if self.iptables.ruleset != self.iptables.previous_ruleset:
                logging.info("Updating Firewall...")
                (added, removed) = self.iptables.ruleset_diff()
                logging.debug("Added rules : %s" % added)
                logging.debug("Removed rules : %s" % removed)

        except Exception, r:
            message = str(r)
            if message == "ServerNotUserApprovedYet":
                logging.debug("polling failure - %s", message)
                logging.info("No policies attached to server. Please"
                             " login to dome9.com and attach a"
                             " policy to start enforcing.")
            elif message == "ServerWasDeleted":
                logging.debug("polling failure - %s", message)
                logging.error("Server was deleted, exit")
                self.config.delete_server_config()
            elif message == 'FailedFirstPolicy':
                # bubble the exception up
                logging.critical("Failed 1st attempt to apply policy, exiting")
                raise ShouldExitException(message)
            else:
                logging.error("polling failure - %s", message, exc_info=True)

    def do_pairing(self, key, servername, secgroups):
        """Run the pairing phase, and save configure as needed"""

        logging.info("Pairing Agent....")
        connection = self.config.connection
        agent = self.config.agent
        config_dir = configuration.CONFIG_DIR

        c = VerifiedHTTPSConnection(
            connection.host, int(connection.port),
            key_file=os.path.join(config_dir, agent.pair_key),
            cert_file=os.path.join(config_dir, agent.pair_cert),
            ca_certs=os.path.join(config_dir, connection.ca_certs),
            strict=int(connection.cert_enforce)
        )

        # Format security groups, if any
        if secgroups:
            secgroups = secgroups.split(',')
            secgroups = ','.join(['"' + x + '"' for x in secgroups])
        request_data = '{"PairingKey":"%s","ServerName":"%s","SecurityGroups": [%s]}' % (
            key, servername, secgroups)
        request_headers = {'Content-Type': 'application/json',
                           'charset': 'utf-8'}

        c.request("POST", self.PAIR_URL, request_data, request_headers)
        pairing_response = c.getresponse().read()

        logging.debug("Pairing arguments: key: %s, servername: %s, security"
                      " groups: %s", key, servername, secgroups)

        try:
            pair = xml_to_attr(pairing_response).PairingResponse
        except AttributeError:
            raise Exception(
                '"PairingResponse" attribute not found in response:\n' +
                pairing_response)

        # Error ? raise assertion
        assert not pair.Error, pair.Error.ErrorNum

        # update the configuration
        self.config.agent.id = pair.AgentID

        logging.debug("Got Agent ID: %s", pair.AgentID)
        logging.debug("Writing client certificate")

        self.config.write_certificate(pair.ClientCert)

        c.close()
        self.config.agent.state = 'polling'
        self.config.save()
        logging.info('Pairing completed successfully')

    def stamp(self):
        """Touch the stampfile"""

        try:
            stampfile = open(self.config.stampfile, 'w')
            stampfile.write(' ')
            stampfile.close()
            os.chmod(self.config.stampfile, 0640)
        except Exception, e:
            logging.error("Can touch stamp file: %s", str(e))

    def start(self):
        """Delay if needed and polling, save iptables and runstates"""

        if self.config.agent.state == 'deleted':
            logging.error("Server was deleted, not running")
            self.do_exit()

        if self.delay and self.config.agent.state == 'polling':
            logging.info("Delaying agent start for %d seconds", self.delay)
            time.sleep(self.delay)

        self.runstates()

    def do_exit(self):
        """Used to exit the program, removing the pid file, usefull in cases
        like ServerWasDeleted.

        Exit code: 3.

        """
        logging.info('Exiting from agent.do_exit')
        logging.info('Deleting pidfile')

        # unlink pidfile
        try:
            os.unlink(self.pidfile)
        except OSError:
            pass
        sys.exit(3)

    def runstates(self):
        """Main loop handling the states of the agent"""

        # we only need to reset once, before applying first poloct
        self.reset_executed = False
        self.first_poll = True  # Used to report agent data on first poll
        self.first_policy_applied = False  # Success in applying first policy
                                           # we got from the server ?
        self.last_seen = None   # Used for applying emergency policy if needed

        # this are used for periodic logging of polls
        self.poll_last_logged = None  # Last time we logged poll stats
        self.poll_attempts = 0        # How many polls since the last log
        self.poll_success = 0         # How many successfull polls since last
                                      # log

        self.do_emergency()

        while True:
            self.stamp()
            try:
                if self.config.agent.state == 'pairing':
                    logging.error('Not paired, please run dome9d init')
                    self.do_exit()

                if self.config.agent.state == 'polling':
                    try:
                        self.do_polling()
                    except ShouldExitException:
                        self.do_exit()

                if self.config.agent.state == 'deleted':
                    self.do_exit()

            except socket.gaierror, conn_error:
                logging.error("Connection error - %s", str(conn_error))
            except socket.timeout, timeout_error:
                logging.error("Connection timeout - %s", str(timeout_error))
            except (socket.error, socket.herror), sock_error:
                logging.error("Socket error - %s", str(sock_error))

            if self.last_seen:
                delta = timedelta(
                    minutes=int(self.config.agent.emergency_minutes))
                if datetime.now() - self.last_seen > delta:
                    logging.error("Last seen more than %s emergency_minutes.",
                                  self.config.agent.emergency_minutes)
                    self.do_emergency()

            self.stamp()
            logging.debug("Sleeping for %s seconds",
                          self.config.agent.interval)
            self.event.wait(int(self.config.agent.interval))
