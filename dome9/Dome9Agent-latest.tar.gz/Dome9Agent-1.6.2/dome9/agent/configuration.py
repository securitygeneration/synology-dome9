"""
Configuration
"""

import os
import base64
from ConfigParser import ConfigParser
import logging
import warnings

# config file location
# Production
CONFIG_DIR = '/etc/dome9'

CONFIG_FILE = os.path.join(CONFIG_DIR, 'agent.conf')


class AttrDict(dict):
    """Enables setting and getting properties as attributes"""
    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)

    def __getattr__(self, name):
        if name in self:
            return self[name]
        else:
            raise AttributeError(name)


class PolicyRule(object):
    """Policy rule"""

    # some protocols have special behavior, first two are for protocol v3
    # compat
    PROTOCOLS_WITH_PORT = ('tcp', 'udp', '1', '6', '17')

    # what to pass to the -m switch
    MATCHES_MAP = {
        '6': 'tcp',
        '17': 'udp',
    }

    def __init__(self, data_port_or_str, rule_type='input'):

        self.rule_type = rule_type

        if isinstance(data_port_or_str, (AttrDict, list)):
            has_protocol = hasattr(data_port_or_str, 'Protocol')
            self.log = data_port_or_str.get('Log')
            if (has_protocol and data_port_or_str.Protocol != '-1'):
                # Regular PolicyRule
                self.protocol = data_port_or_str.Protocol.lower().strip()
                if self.protocol in self.PROTOCOLS_WITH_PORT:
                    port_range = data_port_or_str.PortRange
                    self.portFrom = port_range.get('a:PortFrom')
                    self.portTo = port_range.get('a:PortTo')
                else:
                    self.portFrom = ''
                    self.portTo = ''

                ips = data_port_or_str.IPs
            else:
                # Whitelist or blacklist. White list has Protocol and set to
                # -1 blacklist has only ips
                self.portTo = "*"
                self.portFrom = "*"
                self.protocol = "*"
                if has_protocol:
                    ips = data_port_or_str.IPs
                else:  # shift one level up,  blacklist has only ips
                    ips = data_port_or_str

            # could be a list or dict
            try:
                self.ips = [ips.get('a:string')]
            except AttributeError:
                self.ips = [ip.get('a:string') for ip in ips]
        else:
            try:
                parts = data_port_or_str.split('|')
                self.ips, self.port, self.protocol, self.log = parts
            except ValueError:
                # no log policy in that serialized rule
                self.ips, self.port, self.protocol = parts
                self.log = None

            self.ips = self.ips.split(',')
            if '-' in self.port:
                (self.portFrom, self.portTo) = self.port.split('-')
            else:
                self.portFrom = self.port
                self.portTo = self.port

    @property
    def action(self):
        if self.rule_type == 'blacklist':
            return 'BLACKLISTDROP'  # jump to blacklist drop chain, for logging

        # Not blacklist, is ACCEPT, should we log it ?
        if self.log == 'true':
            return 'LOGACCEPTNEW'

        return 'ACCEPT'

    def __str__(self):
        """String represntaion, for config storage"""
        ips = ','.join(self.ips)
        parts = [ips, self.portFrom + '-' + self.portTo, self.protocol]

        if self.log:
            parts.append(self.log)
        return '|'.join(parts)

    def _get_whitelist_or_generic_rule(self, ip):
        params = []

        if ip != '*':
            if self.rule_type == 'output':
                params.append('-d %s' % ip)
            else:
                params.append('-s %s' % ip)

        params.append("-j %s" % self.action)
        return ' '.join(params)

    def _get_regular_rule(self, ip):
        params = ['-p', self.protocol]

        if ip != '*':
            if self.rule_type == 'output':
                params.extend(['-d', ip])
            else:
                params.extend(['-s', ip])

        # should we add ports or icmp types ?
        if self.protocol in self.PROTOCOLS_WITH_PORT:
            if self.protocol == '1':  # icmp ?
                # 256 denotes all icmp types, and should be ignored
                if self.portFrom != '256':
                    params.extend(['--icmp-type', self.portFrom])
            else:
                params.extend([
                    '-m',
                    # Make sure we pass the correct match, protocol
                    # numbers won't work here
                    self.MATCHES_MAP.get(self.protocol, self.protocol),
                    '--dport',
                    '%s:%s' % (self.portFrom, self.portTo)
                ])

        params.extend(['-j', self.action])
        return ' '.join(params)

    def as_iptable(self):
        """Return the list of IPs, fit to run as iptables command"""

        result = []
        for ip in self.ips:
            if (self.portTo == "*"):  # Whitelist or generic outbound etc
                rule = self._get_whitelist_or_generic_rule(ip)
            else:  # regular PolicyRule
                rule = self._get_regular_rule(ip)

            result.append(rule)
        return result


class Config(AttrDict):
    """Handles static and state configuration,
    enables using attribute access to dict properteis.

    We'll use ConfigParser, it's harder to implement than pickling, but makes
    the run and config files human readable and editable, and as a result,
    suitable for helpdesk/support. This also makes packaing more reasonable,
    and seperates the static from the run config files

    For example if agent.conf contains::

        [connection]
        # dev, for prod use beta.dome9.com
        host = beta1.falconetix.com

    and the instance is called conf, it can be accessed as::

        conf.connection.host

    """

    RUN_CONFIG_FILE = 'run.conf'
    CERT_FILE = 'client.pem'
    DEFAULT_RUN_CONF = {
        'id':                '0',
        'state':             'pairing',
        'interval':          '30',
        'emergency_minutes': '20'
    }
    DEFAULT_STATIC_CONF = {
        'connection': {
            'host':           'agents.dome9.com',
            'port':           '443',
            'ca_certs':       'ca_certs.pem',
            'cert_enforce':   '1',
        },
        'poller': {
            'enabled':    '1',
            'host':       'notifications.dome9.com',
            'ca_certs':   'ca_certs.com',
            'nossl':      '0',
            'port':       '443',
        },
        'agent': {
            'pair_key':    'generic_prod.pem',
            'pair_cert':   'generic_prod.pem',
            'debug':       '0',
            'run_dir':     '/var/lib/dome9',
        },
        'firewall': {
            'allow_icmp':  '0',
            'enable_ftp':  '1',
            'allow_ipsec': '0',
            'synflood_protect': '0',
            'enforce_outbound': '1',
        },
    }

    _singleton = None

    def __new__(cls, *args, **kwargs):
        """
        override for singleton
        """
        if cls._singleton is None:
            cls._singleton = super(Config, cls).__new__(cls, *args, **kwargs)
            return cls._singleton
        logging.debug('Refused to create second instance -'
                      'use classmethod get_config()')
        return None

    def get_config(cls, *args, **kwargs):
        """
        Use get_config to get the Config instance
        """
        if not cls._singleton:
            return cls()
        return cls._singleton

    get_config = classmethod(get_config)

    def __init__(self, config_file=CONFIG_FILE, config_dir=CONFIG_DIR):

        super(Config, self).__init__()

        self._config_file = config_file
        self._config_dir = config_dir

        logging.debug('Using config file %s', config_file)
        self._load_static_config()

        # 12 Deprecate old agent config for various protocols, remove once code
        # paths and templates are cleaned and support is removed
        if (self['firewall']['allow_icmp'] == '1' or
                self['firewall']['allow_ipsec'] == '1'):

            warnings.filterwarnings("always")

            msg = (
                '"allow_icmp" and "allow_ipsec" config flags in agent.conf '
                'are deprecated and will be removed soon. Please configure '
                'them with security policies!.'
            )
            warnings.warn(msg, DeprecationWarning)
            logging.warning(msg)
            warnings.filterwarnings("default")

        self._run_config_file = os.path.join(
            self.agent.run_dir, self.RUN_CONFIG_FILE)
        self._load_run_config()

        self.stampfile = os.path.join(self.agent.run_dir, 'stamp')

    def _load_static_config(self):
        """Load the static config into attributes"""

        #load defaults
        for (k, v) in self.DEFAULT_STATIC_CONF.iteritems():
            self[k] = AttrDict(v)

        static_config = ConfigParser()
        static_config.read(self._config_file)

        for section in static_config.sections():
            self[section].update(static_config.items(section))

    def _load_run_config(self):
        """Load runtime configuration into self.agent, pre-seeded with
        DEFAULT_RUN_CONF.
        """

        # we load run config defaults at start, as we might have a bare empty
        # config file (e.g: Delete server, re-pair it)
        run_config = ConfigParser()
        self.agent.update(self.DEFAULT_RUN_CONF)

        if run_config.read(self._run_config_file):
            for section in run_config.sections():
                if section == 'agent':
                    self.agent.update(AttrDict(run_config.items(section)))
                elif section in ('current_policy', 'emergency_policy'):
                    self[section] = [PolicyRule(r[1]) for r in
                                     run_config.items(section)]
                elif section == 'blacklist':
                    self[section] = [PolicyRule(r[1], rule_type='blacklist')
                                     for r in run_config.items(section)]
                elif section == 'outbound_policy':
                    self[section] = [PolicyRule(r[1], rule_type='output')
                                     for r in run_config.items(section)]
                else:
                    self[section] = AttrDict(run_config.items(section))

        # ensure we have the logging_policy section, otherwise may raise
        # problems for looking it up, and not exists in old run.conf
        if not self.get('logging_policy'):
            self['logging_policy'] = AttrDict()
            self.logging_policy.log_dropped = 'false'

    def get_certificate_filename(self):
        # Backwards compatibility
        if os.path.exists(os.path.join(self.agent.run_dir, 'newcert.pem')):
            return os.path.join(self.agent.run_dir, 'newcert.pem')
        return os.path.join(self.agent.run_dir, self.CERT_FILE)

    # python 2.4 compat
    certificate_filename = property(get_certificate_filename)

    def write_certificate(self, base64_encoded):
        """Create the certificate from base64 encoded string"""

        pfx = base64.decodestring(base64_encoded)

        # write the certificate
        warnings.filterwarnings("ignore")
        (fin, fout) = os.popen4("""openssl pkcs12 -passin "pass:" -nodes """)
        fin.write(pfx)
        fin.flush()
        warnings.filterwarnings("default")

        client_cert = open(self.certificate_filename, 'w')
        for result in fout.readlines():
            client_cert.write(result)
        client_cert.close()
        os.chmod(self.certificate_filename, 0640)

    def save_config_file(self, config):
        """Saves the specified config to _run_config_file,
        and set it's proper mode"""

        config_file = open(self._run_config_file, 'w')
        config.write(config_file)
        config_file.close()

        os.chmod(self._run_config_file, 0640)

    def save(self):
        """Save agent data and policies"""
        config = ConfigParser()

        # agent is a special case, we need id and state, no need to save it all
        config.add_section('agent')
        config.set('agent', 'id', self.agent.id)
        config.set('agent', 'state', self.agent.state)
        config.set('agent', 'interval', self.agent.interval)
        config.set('agent', 'emergency_minutes', self.agent.emergency_minutes)

        config.add_section('logging_policy')
        config.set('logging_policy', 'log_dropped',
                   self.logging_policy.log_dropped)

        sections = ('current_policy', 'emergency_policy', 'blacklist',
                    'outbound_policy')

        for section in sections:
            config.add_section(section)
            for idx, rule in enumerate(self.get(section, [])):
                config.set(section, 'rule%d' % idx, str(rule))

        self.save_config_file(config)

    def update_policy(self, data):
        """Update the policy from the server response"""

        current_policy = data.CurrentPolicy
        emergency_policy = data.EmergencyPolicy
        blacklist = data.BlackList
        outbound_policy = data.OutboundPolicy

        # The way .net serializes the stuff, in case of single rule,
        # we won't get and array, so make sure those are array
        if hasattr(current_policy, 'items'):
            current_policy = [current_policy]

        if hasattr(emergency_policy, 'items'):
            emergency_policy = [emergency_policy]

        if hasattr(outbound_policy, 'items'):
            outbound_policy = [outbound_policy]

        if hasattr(blacklist, 'items'):
            blacklist = [blacklist]

        self['current_policy'] = [PolicyRule(r.AgentDataPort) for r in
                                  current_policy]
        self['emergency_policy'] = [PolicyRule(r.AgentDataPort) for r in
                                    emergency_policy]
        self['outbound_policy'] = [
            PolicyRule(r.AgentDataPort, rule_type='output') for r in
            outbound_policy]

        if blacklist:
            self['blacklist'] = [
                PolicyRule(r, rule_type='blacklist') for r in blacklist]
        else:
            self['blacklist'] = []

        self.agent.interval = data.AgentData.PollingIntervalSeconds
        self.agent.emergency_minutes = data.AgentData.EmergencyModeMinutes

        self['logging_policy']['log_dropped'] = data.LogDropped

    def delete_server_config(self):
        """Handle ServerWasDeleted response config wise:

        - Remove certificate
        - Clear the config file, leaving only a section with state = deleted
        - Remove stamp

        """
        try:
            os.unlink(self.certificate_filename)
            os.unlink(self.stampfile)
        except:
            pass

        self.agent.state = 'deleted'

        config = ConfigParser()

        # agent is a special case, we need id and state, no need to save it all
        config.add_section('agent')
        config.set('agent', 'state', self.agent.state)

        self.save_config_file(config)
