import threading
import time
from xmlreader import xml_to_attr
import configuration
import logging
import os
import random
import httplib
from verifiedhttpsconnection import VerifiedHTTPSConnection


LONG_POLL_PATH = '/subscribe?aid=%s'


class LongPoll(threading.Thread):
    """docstring for AsyncHTTP"""

    def _connection(self):
        """Creates an https or http connection, based on poller config"""

        logging.debug('thread: private key: %s',
                      self.conf.certificate_filename)

        poller_host = self.conf.poller.host

        if not os.path.exists(self.conf.certificate_filename):
            logging.debug('thread: cert does not exist!')

        if getattr(self.conf.poller, 'nossl', '0') == '1':
            poller_port = int(getattr(self.conf.poller, 'port', '80'))
            logging.debug('thread: using non-ssl with host %s:%d',
                          poller_host, poller_port)
            conn = httplib.HTTPConnection(self.conf.poller.host, poller_port)
        else:
            poller_port = int(getattr(self.conf.poller, 'port', '443'))

            logging.debug('thread: using ssl with host %s:%d',
                          poller_host, poller_port)
            conn = VerifiedHTTPSConnection(
                poller_host,
                poller_port,
                key_file=self.conf.certificate_filename,
                cert_file=self.conf.certificate_filename,
                ca_certs=os.path.join(
                    '/etc/dome9', os.path.basename(self.conf.poller.ca_certs)),
                strict=True, timeout=270)
        return conn

    def __init__(self, event):
        threading.Thread.__init__(self)
        logging.debug("thread: Initializing thread")
        self.conf = configuration.Config.get_config()
        self.conn = self._connection()
        self.active = True
        self.event = event
        self.poll_delay = 10
        self.current_attempt = 0

    def _run_command(self, command):
        """
        Run the command received from the notification server
        Currently only PEEK and NOOP supported
        """
        logging.debug("thread: processing command %s", command)
        try:
            if command.NotificationMessage.Command == "POKE":
                self.event.set()
            if command.NotificationMessage.Command == "NOOP":
                return
        except AttributeError:
            logging.info('thread: Bad command received from notificaion' +
                         'server: %s', command)

    def run(self):
        while self.active:
            logging.debug("thread: connecting...")
            try:
                logging.debug("thread: requesting...")
                self.conn = self._connection()
                self.conn.request("GET", LONG_POLL_PATH %
                    self.conf.agent.id)
                logging.debug("thread: waiting for response...")
                self._run_command(xml_to_attr(self.conn.getresponse().read()))
                logging.debug("thread: donecommand...")
                self.poll_delay = 10
                self.current_attempt = 0
                self.conn.close()
            except Exception, e:
                logging.info("thread: Caught Exception: %s", e)
                logging.debug("thread: sleeping for %d", self.poll_delay)
                self.conn.close()
                time.sleep(self.poll_delay)
                # Add incermental delay
                if self.current_attempt < 4:
                    self.current_attempt += 1
                    self.poll_delay *= 2
                    self.poll_delay += random.randint(1, 5)
        logging.debug("thread: stopping...")
