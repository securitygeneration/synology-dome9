import httplib
import os
import socket
import ssl


class VerifiedHTTPSConnection(httplib.HTTPConnection):
    """SSL wrapped HTTPConnection"""

    def __init__(self, host, port=None, key_file=None, cert_file=None,
                ca_certs=None, strict=None, timeout=270):
        httplib.HTTPConnection.__init__(self, host, port)
        self.key_file = key_file
        self.cert_file = cert_file
        if os.path.exists(ca_certs):
            self.ca_certs = ca_certs
        else:
            self.ca_certs = None
        self.strict = strict
        self.timeout = timeout

    def connect(self):
        # overrides the version in httplib so that we do
        #    certificate verification
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        sock.connect((self.host, self.port))
        # wrap the socket using verification with the root
        #    certs in trusted_root_certs
        self.sock = ssl.wrap_socket(sock,
                self.key_file,
                self.cert_file,
                cert_reqs=self.strict,
                ca_certs=self.ca_certs
        )
