from xml.dom.minidom import parseString
from configuration import AttrDict


# based on http://code.activestate.com/recipes/116539/
class NotTextNodeError:
    pass


def getTextFromNode(node):
    """
    scans through all children of node and gathers the
    text. if node has non-text child-nodes, then
    NotTextNodeError is raised.
    """
    t = ""
    for n in node.childNodes:
        if n.nodeType == n.TEXT_NODE:
            t += n.nodeValue
        else:
            raise NotTextNodeError
    return t.strip()


def nodeToDic(node):
    """
    nodeToDic() scans through the children of node and makes a
    dictionary from the content.
    three cases are differentiated:
    - if the node contains no other nodes, it is a text-node
    and {nodeName:text} is merged into the dictionary.
    - if the node has the attribute "method" set to "true",
    then it's children will be appended to a list and this
    list is merged to the dictionary in the form: {nodeName:list}.
    - else, nodeToDic() will call itself recursively on
    the nodes children (merging {nodeName:nodeToDic()} to
    the dictionary).
    """
    dic = AttrDict()
    for n in node.childNodes:
        if n.nodeType != n.ELEMENT_NODE:
            continue

        #detect if we have multiple nodes
        tags = []
        multiple = False

        for c_node in n.childNodes:
            if c_node.nodeType != n.ELEMENT_NODE:
                continue
            if c_node.tagName in tags:
                multiple = True
                break
            else:
                tags.append(c_node.tagName)

        if multiple:
            # node with multiple children:
            # put them in a list
            l = []
            for c in n.childNodes:
                try:
                    text = getTextFromNode(c)
                    l.append(AttrDict({c.nodeName: text}))
                except NotTextNodeError:
                    l.append(AttrDict({c.nodeName: nodeToDic(c)}))
            dic.update({n.nodeName: l})
            continue

        try:
            text = getTextFromNode(n)
            dic.update({n.nodeName: text})
        except NotTextNodeError:
            # 'normal' node
            dic.update({n.nodeName: nodeToDic(n)})
            continue

    return dic


def xml_to_attr(xml):
    dom = parseString(xml)
    return nodeToDic(dom)
