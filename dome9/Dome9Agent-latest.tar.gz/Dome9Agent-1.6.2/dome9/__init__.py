VERSION = '1.6.2'
RELEASE = 1
PACKAGE = 'generic'
