#!/usr/bin/env python
import os
import sys
import time
import atexit
import logging
import traceback
import exceptions
from optparse import OptionParser
from agent import Dome9Agent
from agent.configuration import Config
from agent.util import get_server_name
from dome9 import VERSION, RELEASE
from signal import SIGTERM, signal


COMMANDS = ('start', )
FG_COMMANDS = ('stop', 'pair', 'version')

USAGE = """usage: %prog [options] command

commands:
help      show this help message
start     start the dome9 daemon
stop      stop the dome9 daemon
version   print version and exit
pair      initialize and pair with dome9 servers
"""


class Daemon(object):
    """ A generic daemon class.

        Usage: subclass the Daemon class and override the run() method
        """
    def __init__(self, pidfile, stdin='/dev/null',
                 stdout='/dev/null',
                 stderr='/dev/null'):
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr
        self.pidfile = pidfile
        self.agt = None

    def daemonize(self):
        """
        do the UNIX double-fork magic, see Stevens' "Advanced
        Programming in the UNIX Environment" for details (ISBN 0201563177)
        http://www.erlenstar.demon.co.uk/unix/faq_2.html#SEC16

        """
        try:
            pid = os.fork()
            if pid > 0:
                # exit first parent
                sys.exit(0)
        except OSError, e:
            sys.stderr.write("fork #1 failed: %d (%s)\n" % (e.errno,
                                                            e.strerror))
            sys.exit(1)

        # decouple from parent environment
        os.chdir("/")
        os.setsid()
        os.umask(0)

        # do second fork
        try:
            pid = os.fork()
            if pid > 0:
                # exit from second parent
                sys.exit(0)
        except OSError, e:
            sys.stderr.write("fork #2 failed: %d (%s)\n" % (e.errno,
                                                            e.strerror))
            sys.exit(1)

        # redirect standard file descriptors
        sys.stdout.flush()
        sys.stderr.flush()
        si = file(self.stdin, 'r')
        so = file(self.stdout, 'a+')
        se = file(self.stderr, 'a+', 0)
        os.dup2(si.fileno(), sys.stdin.fileno())
        os.dup2(so.fileno(), sys.stdout.fileno())
        os.dup2(se.fileno(), sys.stderr.fileno())

        # write pidfile
        atexit.register(self.restore_iptables)
        signal(SIGTERM, self.sig_handler)
        pid = str(os.getpid())
        file(self.pidfile, 'w+').write("%s\n" % pid)

    def sig_handler(self, signum, _):
        """ Gracefully quit (run atexit handler) """
        logging.error("Signal Recieved: %s", signum)
        sys.exit(3)

    def restore_iptables(self):
        """Restore a working iptables configuration
           Take into account that restoration might fail and
           fall back to emergency and if that fails fall back
           to port 22tcp open any"""
        if (getattr(self, 'agt', False) and
                getattr(self.agt, 'longpoller', False)):
            logging.info('found running poller.. stopping')
            self.agt.longpoller.active = False
        if (not getattr(self, 'agt', False) or
                self.agt.control_firewall == "False" or
                not self.agt.control_firewall):
            logging.info('Not resetting firewall, no control...')
        else:
            try:
                self.agt.iptables.restore()
            except IOError:
                logging.error('Failed to restore iptables backup..'
                              'Trying Emergency policy')
                try:
                    if not self.agt.do_emergency():
                        logging.error('Emergency Policy Empty')
                except Exception:
                    logging.error('Failed to restore emergency policy')
            logging.info('Opening port 22')
            self.agt.iptables.emergency_open_ssh()

    def start(self):
        """ Start the daemon """

        # Check for a pidfile to see if the daemon already runs
        try:
            pf = file(self.pidfile, 'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None

        if pid:
            message = "pidfile %s already exist. Daemon already running?\n"
            sys.stderr.write(message % self.pidfile)
            sys.exit(1)

        # Start the daemon
        self.daemonize()
        logging.info('Starting dome9 daemon')
        self.run()

    def stop(self):
        """ Stop the daemon """

        # Get the pid from the pidfile
        try:
            pf = file(self.pidfile, 'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None

        if not pid:
            message = "pidfile %s does not exist. Daemon not running?\n"
            sys.stderr.write(message % self.pidfile)
            return  # not an error in a restart

        logging.info('Stopping dome9 daemon')
        # Try killing the daemon process
        try:
            while 1:
                os.kill(pid, SIGTERM)
                time.sleep(0.1)
        except OSError, err:
            err = str(err)
            if err.find("No such process") > 0:
                if os.path.exists(self.pidfile):
                    os.remove(self.pidfile)
            else:
                print str(err)
                sys.exit(1)

    def restart(self):
        """ Restart the daemon """

        self.stop()
        self.start()

    def run(self):
        """
        You should override this method when you subclass Daemon. It will be
        called after the process has been daemonized by start() or restart().
        """
        pass


class Dome9Daemon(Daemon):
    """Run agent as daemon"""
    def __init__(self, options):
        super(Dome9Daemon, self).__init__(options.pidfile)
        self.options = options

    def run(self):
        self.agt = Dome9Agent(self.options)
        self.agt.start()

    def devrun(self):
        """ This is to be run from debugger/IDE """
        self.run()


class Dome9Foreground(object):
    """Run agent in foreground"""
    def __init__(self, options):
        super(Dome9Foreground, self).__init__()
        self.options = options

    def version(self):
        """Print agent version and exit"""
        print 'Dome9Agent Version %s-%s' % (VERSION, RELEASE)

    def pair(self):
        """pair the agent and exit"""
        if self.options.pairkey == '':
            print 'Pairing Key missing. Run with:'
            print ('dome9d pair -k <pairing-key> '
                   '[-s <servername> -g <policy groups>]')
            sys.exit(1)
        logging.debug(
            'Pairing and exit - pairkey = %s, servername = %s, secgroups = %s',
            self.options.pairkey, self.options.servername,
            self.options.secgroups)
        self.agt = Dome9Agent(self.options)

        if not self.options.servername:
            print 'Can not detect server name. Please specify -s <servername>'
            sys.exit(1)

        try:
            self.agt.do_pairing(self.options.pairkey, self.options.servername,
                                self.options.secgroups)
        except AssertionError, r:
            logging.debug("pairing failure - %s" % str(r))
            if str(r) == "UnknownPairingKey":
                logging.fatal('Invalid Pairing Key. Pairing Failed')
            elif str(r) == "WrongSecGroups":
                logging.fatal('Invalid/Non-existent Security Group(s). '
                              'Pairing Failed')
            else:
                logging.fatal(
                    'Unknown Error. Pairing Failed (run with -D to debug)',
                    exc_info=True)
            sys.exit(1)
        except:
            logging.fatal("Pairing error", exc_info=True)
            sys.exit(1)

        # All ok, pair successful, start daemon
        print 'Starting Dome9Agent ......'
        self.agt = Dome9Daemon(self.options)
        self.agt.start()

    def start(self):
        self.agt = Dome9Agent(self.options)
        self.agt.start()

    def stop(self):
        """ Stop the daemon """

        # Get the pid from the pidfile
        try:
            pf = file(self.options.pidfile, 'r')
            pid = int(pf.read().strip())
            pf.close()
        except IOError:
            pid = None

        if not pid:
            message = "pidfile %s does not exist. Daemon not running?\n"
            sys.stderr.write(message % self.options.pidfile)
            return  # not an error in a restart

        # Try killing the daemon process
        try:
            while 1:
                os.kill(pid, SIGTERM)
                time.sleep(0.1)
        except OSError, err:
            err = str(err)
            if err.find("No such process") > 0:
                if os.path.exists(self.options.pidfile):
                    os.remove(self.options.pidfile)
            else:
                print str(err)
                sys.exit(1)


def dome9d_opts_parser():
    """Return OptionParser instance"""

    optparser = OptionParser(usage=USAGE)

    optparser.add_option(
        '-p', '--pidfile',
        dest='pidfile', default='/var/run/dome9d.pid',
        help='Location of PID file [default: %default ]')

    optparser.add_option(
        '-l', '--logfile',
        dest='logfile', default='/var/log/dome9d.log',
        help='Location of log file [default: %default ]')

    # Initial delay for beta period
    optparser.add_option(
        '-z', '--delay',
        dest='delay', default=0, type='int',
        help='Initial dealy before running states [default: %default ]')

    optparser.add_option(
        '-F', '--foreground',
        action='store_true', dest='foreground', default=False,
        help='Run in foreground [default: %default ]')

    optparser.add_option(
        '-D', '--debug',
        action='store_true', dest='debug', default=False,
        help='Loglevel debug [default: %default ]')

    optparser.add_option(
        '-k', '--pairkey',
        dest='pairkey', default='',
        help='[pair] Pairing key - required for init')

    optparser.add_option(
        '-g', '--secgroups',
        dest='secgroups', default='',
        help=('[pair] Initial Security groups, '
              'comma seperated [default: %default ]'))

    optparser.add_option(
        '-s', '--servername',
        dest='servername', default=get_server_name(),
        help='[pair] Initial server name [default: %default ]')

    return optparser


def log_exception_hook(ex_type, ex_value, trace_back):
    """Catch unhandled exceptions and log them, try to restore iptables"""
    if ex_type is exceptions.KeyboardInterrupt:
        logging.error('User keyboard break')
        sys.exit(0)

    tb_message = ''.join(traceback.format_tb(trace_back))
    logging.error('Unhandled exception %s %s:\n%s',
                  ex_value, ex_type, tb_message)

    sys.exit(2)


def parse_options_and_run():
    """optparse the command line options, and run the daemon"""

    sys.excepthook = log_exception_hook

    # Let's parse the options
    optparser = dome9d_opts_parser()
    options, args = optparser.parse_args()

    if len(args) != 1 or args[0] not in COMMANDS + FG_COMMANDS:
        optparser.print_help()
        sys.exit(1)

    if args[0] in FG_COMMANDS:
        options.foreground = True

    # Setup Logging (remove
    logging.basicConfig(level=logging.INFO, filename=options.logfile,
                        format='%(asctime)s %(levelname)s %(message)s')

    # create console handler and set level to debug
    ch = logging.StreamHandler()

    # create formatter
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logging.getLogger().addHandler(ch)

    if options.debug:
        ch.setLevel(logging.DEBUG)

    c = Config.get_config()
    if options.foreground:
        if c.agent.state == 'polling' and args[0] == 'pair':
            print "Agent already paired. Run 'dome9d start'"
            sys.exit(1)
        daemon = Dome9Foreground(options)
    else:
        if c.agent.state == 'polling':
            logging.getLogger().removeHandler(ch)
            daemon = Dome9Daemon(options)
        if c.agent.state == 'pairing':
            print ('Agent not paired. Pair this agent by running: '
                   'dome9d pair -k <pair-key>')
            sys.exit(4)
        if c.agent.state == 'deleted':
            print 'Agent was deleted.'
            sys.exit(0)

    if options.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    command = args[0]

    #execute the command method on the daemon
    getattr(daemon, command)()

    sys.exit(0)

if __name__ == "__main__":
    parse_options_and_run()
