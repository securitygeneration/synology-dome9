#!/usr/bin/env python

import sys
from distutils.core import setup
from distutils.command.install import install
from os import mkdir, geteuid
from subprocess import call

from dome9 import VERSION

if sys.version_info[0] != 2 or sys.version_info[1] < 4:
    print 'Dome9 Agent requires python >= 2.4 and < 3.0'
    sys.exit(1)
try:
    from xml.dom.minidom import parseString
except ImportError:
    print 'Dome9Agent Requires python-xml'
    sys.exit(1)

try:
    import ssl
except ImportError:
    print 'Dome9Agent Requires python-ssl'
    sys.exit(1)

class pre_install(install):
    """docstring for post_install"""
    def run(self):
        if geteuid():
            print 'Please run installation as root'
            sys.exit(1)
        print "Creating /var/lib/dome9..."
        try:
            mkdir("/var/lib/dome9", 0700)
        except OSError:
            pass
        rv = call('iptables -L > /dev/null', shell=True)
        rv = rv + call('iptables-save > /var/lib/dome9/iptables_backup', shell=True)
        rv = rv + call('iptables-restore --test < /var/lib/dome9/iptables_backup > /dev/null', shell=True)
        if rv:
            print 'iptables not found! Please install iptables and retry'
            sys.exit(1)
        rv = call('openssl version > /dev/null', shell=True)
        if rv:
            print 'openssl binary not found! Please install openssl and retry'
            sys.exit(1)
        install.run(self)

        
setup(name='Dome9Agent',
    version=VERSION,
    description='Dome9 firewall agent',
    author='Dome9 Security',
    author_email='info@dome9.com',
    url='http://dome9.com/',
    packages=['dome9', 'dome9.agent', 'dome9.pystache'],
    package_data={'dome9.agent': ['iptables.boilerplate'],
                  'dome9.pystache': ['LICENSE', 'README.rst'],
                 },
    data_files=[('', ['contrib/dome9d_init']),
                ('', ['contrib/dome9d_cron']),
                ('', ['INSTALL']),
                ('/bin/', ['bin/dome9d', 'bin/dome9watchdog']),
                ('/etc/dome9/', ['etc/dome9/agent.conf', 'etc/dome9/ca-certs.pem', 'etc/dome9/generic_prod.pem']),
                ('/usr/sbin/', ['bin/dome9d', 'bin/dome9watchdog']),
               ],
    cmdclass={"install": pre_install},

)
